self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "f0c62aedabdb63201fa7",
    "url": "/static/js/main.f0c62aed.chunk.js"
  },
  {
    "revision": "070821e4cbf54f6a50a6",
    "url": "/static/js/1.070821e4.chunk.js"
  },
  {
    "revision": "f0c62aedabdb63201fa7",
    "url": "/static/css/main.b71c2136.chunk.css"
  },
  {
    "revision": "070821e4cbf54f6a50a6",
    "url": "/static/css/1.11e09f74.chunk.css"
  },
  {
    "revision": "06b443edf3e74078ab33bab8fcc5c56f",
    "url": "/index.html"
  }
];