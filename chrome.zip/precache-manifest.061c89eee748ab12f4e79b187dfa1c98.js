self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "f9486eed25f37cf40cb3",
    "url": "/static/js/main.f9486eed.chunk.js"
  },
  {
    "revision": "68b9567be5ebe42387f2",
    "url": "/static/js/2.68b9567b.chunk.js"
  },
  {
    "revision": "f9486eed25f37cf40cb3",
    "url": "/static/css/main.38587519.chunk.css"
  },
  {
    "revision": "68b9567be5ebe42387f2",
    "url": "/static/css/2.010dabb5.chunk.css"
  },
  {
    "revision": "3600adccf1b35195f1e0c338eb69cb27",
    "url": "/index.html"
  }
];