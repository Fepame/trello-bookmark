self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "06e83b0ce6c3d9816bc0",
    "url": "/static/js/main.06e83b0c.chunk.js"
  },
  {
    "revision": "06025a2df9b50dfad2f6",
    "url": "/static/js/2.06025a2d.chunk.js"
  },
  {
    "revision": "06e83b0ce6c3d9816bc0",
    "url": "/static/css/main.38587519.chunk.css"
  },
  {
    "revision": "06025a2df9b50dfad2f6",
    "url": "/static/css/2.010dabb5.chunk.css"
  },
  {
    "revision": "3e0e0609006d13bb92fed3cb7944367d",
    "url": "/index.html"
  }
];