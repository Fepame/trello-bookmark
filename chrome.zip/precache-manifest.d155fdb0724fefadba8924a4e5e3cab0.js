self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "395b90e7b50fbfcbd4d5",
    "url": "/static/js/main.395b90e7.chunk.js"
  },
  {
    "revision": "72ffd1a2da4c4d7acd91",
    "url": "/static/js/1.72ffd1a2.chunk.js"
  },
  {
    "revision": "395b90e7b50fbfcbd4d5",
    "url": "/static/css/main.3ad55945.chunk.css"
  },
  {
    "revision": "72ffd1a2da4c4d7acd91",
    "url": "/static/css/1.11e09f74.chunk.css"
  },
  {
    "revision": "bf1efb1ff159ddd48e15811917c0883b",
    "url": "/index.html"
  }
];